package com.orangomango.projectile.ui;

import javafx.scene.layout.TilePane;

/**
 * Screen default vars
 */
public abstract class Screen{
	public abstract TilePane getScene();
}
